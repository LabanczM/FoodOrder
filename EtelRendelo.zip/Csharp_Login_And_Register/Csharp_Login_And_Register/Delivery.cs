﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Csharp_Login_And_Register
{
    public partial class Delivery : Form
    {
        public Delivery()
        {
            InitializeComponent();
        }

        private void ettermek_Click(object sender, EventArgs e)
        {
            Restaurants restaurants = new Restaurants();
            restaurants.Show();
            Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Delivery delivery = new Delivery();
            delivery.Show();
            Visible = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void FoodOrder_Click(object sender, EventArgs e)
        {

        }

        private void account_Click(object sender, EventArgs e)
        {
            Account account = new Account();
            account.Show();
            Visible = false;
        }
    }
}
