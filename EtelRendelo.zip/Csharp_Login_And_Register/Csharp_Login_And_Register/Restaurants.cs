﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Csharp_Login_And_Register
{
    public partial class Restaurants : Form
    {
        public Restaurants()
        {
            InitializeComponent();
        }

        private void ettermek_Click(object sender, EventArgs e)
        {
            Restaurants restaurants = new Restaurants();
            restaurants.Show();
            Visible = false;
        }

        private void delivery_Click(object sender, EventArgs e)
        {
            Delivery delivery = new Delivery();
            delivery.Show();
            Visible = false;
        }

        private void account_Click(object sender, EventArgs e)
        {
            Account account = new Account();
            account.Show();
            Visible = false;
        }
    }
}
