﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Vasarlo
{
    /// <summary>
    /// Interaction logic for Etelek.xaml
    /// </summary>
    public partial class Etelek : Window
    {
        Dictionary<string, string> etterem = new Dictionary<string, string>();
        List<int> ar = new List<int>();
        List<int> ido = new List<int>();
        static string ordertorest = "";
        static int ordertorestin = 0;

        public Etelek()
        {
            InitializeComponent();
        }
        public void Kilistaz(string nev, int ind)
        {
            ordertorest = nev;
            ordertorestin = ind + 1;
            etterem.Clear();
            try
            {
                string message = "bc2;" + nev;
                string message_back = Server_connection.GetInstance().SendMessageToServer(message, true);

                if (message_back != "failed")
                {
                    message_back = message_back.Remove(message_back.Length - 1);
                    foreach (var item in message_back.Split('?'))
                    {
                        etterem.Add(item.Split(';')[0], item.Split(';')[1]);
                        ar.Add(Convert.ToInt32(item.Split(';')[2]));
                        ido.Add(Convert.ToInt32(item.Split(';')[3]));
                    }
                }
            }
            catch (Exception e)
            {
                //MessageBox.Show("Server Error");
            }
            Thickness margin = new Thickness();
            margin.Left = 5;
            margin.Bottom = 5;
            margin.Right = 5;
            margin.Top = 5;

            for (int i = 0; i < etterem.Count; i++)
            {
                Button button = new Button()
                {
                    Name = string.Format(etterem.ElementAt(i).Key),
                    Margin = margin,
                    Content = new Image
                    {

                        Source = new BitmapImage(new Uri(etterem.ElementAt(i).Value)),
                        Stretch = Stretch.Fill,
                        VerticalAlignment = VerticalAlignment.Center,
                    }
                };

                if (i < 7)
                {
                    Grid.SetRow(button, 3);
                    Grid.SetColumn(button, i + 1);
                }
                else
                {
                    Grid.SetRow(button, 4);
                    Grid.SetColumn(button, i - 5);
                }

                button.Click += new RoutedEventHandler(Login_Click);
                this.grid.Children.Add(button);
            }
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            string et_neve = b.Name.ToString();
            int index = 0;
            int far = 0;
            int fido = 0;

            for (int i = 0; i < etterem.Count(); i++)
            {
                if (etterem.ElementAt(i).Key == et_neve)
                    index = i;
            }
            far = ar[index];
            fido = ido[index];
            
            //MessageBox.Show(et_neve);
            MessageBoxResult proc = MessageBox.Show("Név: " + et_neve + "\nÁr: " + far + "\nElkészítési idő: " + fido + "perc\nMeg szeretné rendelni?", "Validation", MessageBoxButton.YesNo);

            switch (proc)
            {
                case MessageBoxResult.Yes:
                    Order(et_neve, far, fido);
                    break;
                case MessageBoxResult.No:
                    //MessageBox.Show("Re");
                    break;
            }

        }
        public void Order(string e_nev, int f_ar, int f_ido)
        {
            string message = "neworder;" + e_nev + ";" + ordertorestin +";" + User.GetInstance().Database_id + ";" + f_ar + ";"+f_ido;
            //MessageBox.Show(message);
            string message_back = Server_connection.GetInstance().SendMessageToServer(message, true);

            if (message_back == "OK")
                MessageBox.Show("Rendelés leadva!");

            else
                MessageBox.Show("Rendelés sikertelen!");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Ettermek et = new Ettermek();
            et.Show();
            this.Close();

        }
    }
}
