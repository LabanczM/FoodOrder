﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Vasarlo
{
    /// <summary>
    /// Interaction logic for Ettermek.xaml
    /// </summary>
    public partial class Ettermek : Window
    {
        Dictionary<string, string> etterem = new Dictionary<string, string>();

        public Ettermek()
        {
            InitializeComponent();
            NewButton();
        }
        public void NewButton()
        {

            etterem.Clear();
            try
            {
                string message = "Buttoncont";
                string message_back = Server_connection.GetInstance().SendMessageToServer(message, true);

                if (message_back != "failed")
                {
                    message_back = message_back.Remove(message_back.Length - 1);
                    foreach (var item in message_back.Split('?'))
                    {
                        etterem.Add(item.Split(';')[0], item.Split(';')[1]);
                    }
                }
            }
            catch (Exception e)
            {
                //MessageBox.Show("Server Error");
            }
            Thickness margin = new Thickness();
            margin.Left = 5;
            margin.Bottom = 5;
            margin.Right = 5;
            margin.Top = 5;

            for (int i = 0; i < etterem.Count; i++)
            {
                Button button = new Button()
                {
                    Name = string.Format(etterem.ElementAt(i).Key),
                    Margin = margin,
                    Content = new Image
                    {

                        Source = new BitmapImage(new Uri(etterem.ElementAt(i).Value)),
                        Stretch = Stretch.Fill,
                        VerticalAlignment = VerticalAlignment.Center,
                    }
                };

                if (i < 7)
                {
                    Grid.SetRow(button, 3);
                    Grid.SetColumn(button, i + 1);
                }
                else
                {
                    Grid.SetRow(button, 4);
                    Grid.SetColumn(button, i - 5);
                }

                button.Click += new RoutedEventHandler(Login_Click);
                this.grid.Children.Add(button);
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
        private void Login_Click(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            string ettrem_neve = b.Name.ToString();
            int index = 0;
            for (int i = 0; i < etterem.Count(); i++)
            {
                if (etterem.ElementAt(i).Key == ettrem_neve)
                    index = i;
            }
            Etelek ek = new Etelek();
            ek.Kilistaz(ettrem_neve, index);
            ek.Show();
            this.Close();

        }
    }
}
