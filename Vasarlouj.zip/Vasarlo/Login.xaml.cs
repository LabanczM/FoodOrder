﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Vasarlo
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string message_to_send = "loginbuyer" + ";" + User.GetInstance().Database_id + ";" + tel.Text + ";" + pwd.Text;
            try
            {
                string response = Server_connection.GetInstance().SendMessageToServer(message_to_send, true);

                if (response == "accepted")
                {
                    Ettermek ete = new Ettermek();
                    ete.Show();
                    this.Close();
                }
                else
                {
                    if (response == "failed")
                    {
                        MessageBox.Show("Rosz adatok");
                    }
                    else
                    { MessageBox.Show("Adatbázis hiba"); }
                }

            }
            catch (Exception)
            {
                MessageBox.Show("Hiba");
            }
        }

        private void Reg_Click(object sender, RoutedEventArgs e)
        {
            Reg r = new Reg();
            r.Show();
            this.Close();
        }
    }
}
