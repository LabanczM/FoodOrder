﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Vasarlo
{
    /// <summary>
    /// Interaction logic for Reg.xaml
    /// </summary>
    public partial class Reg : Window
    {
        public Reg()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                string connectionString = "server=remotemysql.com;userid=pP2C6kiKVe;password=nCxeCZCMf7;database=pP2C6kiKVe";
                MySqlConnection connection = new MySqlConnection(connectionString);
                connection.Open();
                string nev = "'" + txtnev.Text.ToString() + "', ";
                string email = "'" + txtemail.Text.ToString() + "', ";
                string cim = "'" + txtvaros.Text.ToString() + ":" + txtutca.Text.ToString() + "', ";
                string jel = "'" + txttel.Text.ToString() + "', ";
                string tel = "'" + txtjel.Text.ToString() + "'";

                string query = "INSERT INTO Vasarlo(Nev, Email, Cim, Jelszo, Tel) VALUES (" + nev + email + cim + jel + tel + ")";
                MessageBox.Show(query);

                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Sikeres regisztrálás");
                Login ln = new Login();
                ln.Show();
                this.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Login ln = new Login();
            ln.Show();
            this.Close();

        }
    }
}
