﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace Vasarlo
{
    public sealed class Server_connection
    {
        private static string ip = "79.120.156.83";
        //private static string ip = "192.168.1.107";
        private static int port = 8081;

        private static Server_connection instance = null;
        private TcpClient client;

        public Server_connection()
        {
            // Thread t = new Thread(WaitForCustomers_thread_function);
            // t.Start();
        }

        public static Server_connection GetInstance()
        {
            if (instance == null)
            {
                instance = new Server_connection();
            }
            return instance;
        }

        // message: id;userid;message
        // id list: loginrestaurante,logincourier,loginbuyer,getfooglist,getcourierlist,getmenus,getrestaurants,regC,regB,regR,closethisclient
        public string SendMessageToServer(String message, bool has_return = false)
        {
            try
            {
                message += "$";
                // connect to server
                client = new TcpClient();
                client.Connect(ip, port); // where to connect

                // send ip and id to server for identification
                Stream stm = client.GetStream();
                ASCIIEncoding asen = new ASCIIEncoding();
                byte[] ba = asen.GetBytes(message);
                stm.Write(ba, 0, ba.Length);

                if (has_return)
                {
                    byte[] bb = new byte[500];
                    int k = stm.Read(bb, 0, 500);
                    string response = "";
                    for (int i = 0; i < k; i++)
                    {
                        response += Convert.ToChar(bb[i]);
                    }

                    client.Close();

                    if (message.Contains("login") && response.Contains("accepted"))
                    {
                        User.GetInstance().Database_id = int.Parse(response.Split(';')[1]);
                        User.GetInstance().Nev = response.Split(';')[2];

                        //Thread waiting = new Thread(() => WaitForCustomers_thread_function(User.GetInstance().Database_id + ",U"));
                        //waiting.Start();

                        return "accepted";
                    }

                    if(message.Contains("futar") && response.Contains("accepted"))
                    {

                    }
                    

                    return response;
                }

                client.Close();
                return "";
            }

            catch (Exception e)
            {
                return "";
            }
        }

        public void WaitForCustomers_thread_function(string username)
        {
            //MessageBox.Show(username);
            try
            {
                string message = "Waiting;" + username + "$";
                // connect to server
                client = new TcpClient();
                client.Connect(ip, port); // where to connect


                Stream stm = client.GetStream();
                ASCIIEncoding asen = new ASCIIEncoding();
                byte[] ba = asen.GetBytes(message);
                stm.Write(ba, 0, ba.Length);

                while (true)
                {
                    byte[] bb = new byte[500];
                    int k = stm.Read(bb, 0, 500);
                    string response = "";
                    for (int i = 0; i < k; i++)
                    {
                        response += Convert.ToChar(bb[i]);
                    }
                    MessageBox.Show(response);
                    if (response == "alert")
                    {
                        //MainWindow.MessageFromServer("Alert from server");

                        // beep ----------
                        Thread.Sleep(500);
                        // beep ----------
                    }
                }

                client.Close();
            }
            catch (Exception e)
            {
                client.Close();
            }

        }
    }
}
