﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vasarlo
{
    class User
    {

        private int database_id;
        private string nev;
        private static User instance;

        public string Nev { get => nev; set => nev = value; }
        public int Database_id { get => database_id; set => database_id = value; }

        private User()
        {
            this.database_id = -1;
            this.nev = null;
        }
        public static User GetInstance()
        {
            if (instance == null)
            {
                instance = new User();
            }
            return instance;
        }

        public void SetDefault()
        {
            this.database_id = -1;
            this.nev = null;
        }
    }
}
